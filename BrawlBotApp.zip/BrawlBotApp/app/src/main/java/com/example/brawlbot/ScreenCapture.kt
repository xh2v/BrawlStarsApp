package com.example.brawlbot

import android.graphics.Bitmap
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager

class ScreenCapture {
    private var mediaProjection: MediaProjection? = null

    fun startCapture() {
        // TODO: Configurer MediaProjection avec un intent depuis l’activité
        // Nécessite une permission utilisateur
    }

    fun processFrame(frame: Bitmap) {
        // TODO: Convertir le Bitmap en Mat pour OpenCV
        // Analyser l’image pour détecter les ennemis ou gemmes
    }
}
