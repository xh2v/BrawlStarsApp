package com.example.brawlbot

import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import org.opencv.android.OpenCVLoader
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.concurrent.thread

class FloatingBotService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: LinearLayout
    private var isRunning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        // Initialiser OpenCV
        if (!OpenCVLoader.initDebug()) {
            Toast.makeText(this, "Erreur lors du chargement d'OpenCV", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        // Configurer la fenêtre flottante
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_layout, null) as LinearLayout

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 100

        windowManager.addView(floatingView, params)

        // Configurer les boutons
        val attackButton = floatingView.findViewById<Button>(R.id.attack_button)
        val farmButton = floatingView.findViewById<Button>(R.id.farm_button)
        val dodgeButton = floatingView.findViewById<Button>(R.id.other_button)

        attackButton.setOnClickListener {
            isRunning = !isRunning
            Toast.makeText(this, if (isRunning) "Attaque démarrée" else "Attaque arrêtée", Toast.LENGTH_SHORT).show()
            if (isRunning) startAttackScript()
        }
        farmButton.setOnClickListener {
            isRunning = !isRunning
            Toast.makeText(this, if (isRunning) "Auto-farm démarré" else "Auto-farm arrêté", Toast.LENGTH_SHORT).show()
            if (isRunning) startFarmScript()
        }
        dodgeButton.setOnClickListener {
            isRunning = !isRunning
            Toast.makeText(this, if (isRunning) "Esquive démarrée" else "Esquive arrêtée", Toast.LENGTH_SHORT).show()
            if (isRunning) startDodgeScript()
        }
    }

    private fun startAttackScript() {
        thread {
            while (isRunning) {
                try {
                    // TODO: Remplacer par une vraie capture d’écran avec MediaProjection
                    val screen = Bitmap.createBitmap(1080, 1920, Bitmap.Config.ARGB_8888)
                    val mat = Mat()
                    Utils.bitmapToMat(screen, mat)
                    val enemies = detectEnemies(mat)
                    if (enemies.isNotEmpty()) {
                        val closestEnemy = enemies.minByOrNull { it.x * it.x + it.y * it.y } ?: continue
                        simulateTap(closestEnemy.x.toFloat(), closestEnemy.y.toFloat())
                    }
                    Thread.sleep((100 + (0..50).random()).toLong()) // Délai aléatoire
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun startFarmScript() {
        thread {
            while (isRunning) {
                try {
                    // TODO: Remplacer par une vraie capture d’écran
                    val screen = Bitmap.createBitmap(1080, 1920, Bitmap.Config.ARGB_8888)
                    val mat = Mat()
                    Utils.bitmapToMat(screen, mat)
                    val gems = detectGems(mat)
                    if (gems.isNotEmpty()) {
                        val closestGem = gems.minByOrNull { it.x * it.x + it.y * it.y } ?: continue
                        simulateTap(closestGem.x.toFloat(), closestGem.y.toFloat())
                    } else {
                        simulateTap(540f, 960f) // Centre de l’écran
                    }
                    if (isMatchEnded(mat)) {
                        simulateTap(1000f, 1800f) // Bouton “Replay”
                    }
                    Thread.sleep((200 + (0..100).random()).toLong()) // Délai aléatoire
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun startDodgeScript() {
        thread {
            while (isRunning) {
                try {
                    // TODO: Remplacer par une vraie capture d’écran
                    val screen = Bitmap.createBitmap(1080, 1920, Bitmap.Config.ARGB_8888)
                    val mat = Mat()
                    Utils.bitmapToMat(screen, mat)
                    val projectiles = detectProjectiles(mat)
                    if (projectiles.isNotEmpty()) {
                        val closestProjectile = projectiles.minByOrNull { it.x * it.x + it.y * it.y } ?: continue
                        // S’éloigner du projectile
                        simulateTap(540f - (closestProjectile.x - 540f), 960f - (closestProjectile.y - 960f))
                    }
                    Thread.sleep((50 + (0..30).random()).toLong()) // Délai rapide pour esquive
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun detectEnemies(frame: Mat): List<Point> {
        val hsv = Mat()
        Imgproc.cvtColor(frame, hsv, Imgproc.COLOR_RGB2HSV)
        val lowerRed = Scalar(0.0, 100.0, 100.0)
        val upperRed = Scalar(10.0, 255.0, 255.0)
        val mask = Mat()
        Core.inRange(hsv, lowerRed, upperRed, mask)
        val contours = mutableListOf<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        return contours.mapNotNull { contour ->
            val rect = Imgproc.boundingRect(contour)
            if (rect.width > 20 && rect.height > 20) { // Filtrer les petits contours
                Point(rect.x + rect.width / 2.0, rect.y + rect.height / 2.0)
            } else null
        }
    }

    private fun detectGems(frame: Mat): List<Point> {
        val hsv = Mat()
        Imgproc.cvtColor(frame, hsv, Imgproc.COLOR_RGB2HSV)
        val lowerGreen = Scalar(40.0, 100.0, 100.0)
        val upperGreen = Scalar(80.0, 255.0, 255.0)
        val mask = Mat()
        Core.inRange(hsv, lowerGreen, upperGreen, mask)
        val contours = mutableListOf<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        return contours.mapNotNull { contour ->
            val rect = Imgproc.boundingRect(contour)
            if (rect.width > 10 && rect.height > 10) {
                Point(rect.x + rect.width / 2.0, rect.y + rect.height / 2.0)
            } else null
        }
    }

    private fun detectProjectiles(frame: Mat): List<Point> {
        val hsv = Mat()
        Imgproc.cvtColor(frame, hsv, Imgproc.COLOR_RGB2HSV)
        val lowerYellow = Scalar(20.0, 100.0, 100.0)
        val upperYellow = Scalar(30.0, 255.0, 255.0)
        val mask = Mat()
        Core.inRange(hsv, lowerYellow, upperYellow, mask)
        val contours = mutableListOf<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        return contours.mapNotNull { contour ->
            val rect = Imgproc.boundingRect(contour)
            if (rect.width > 15 && rect.height > 15) {
                Point(rect.x + rect.width / 2.0, rect.y + rect.height / 2.0)
            } else null
        }
    }

    private fun isMatchEnded(frame: Mat): Boolean {
        // TODO: Implémenter la détection de l’écran de fin de partie
        // Exemple : Chercher un texte ou un bouton spécifique
        return false
    }

    private fun simulateTap(x: Float, y: Float) {
        // TODO: Utiliser BotAccessibilityService pour simuler un tap
        // Exemple simplifié :
        Toast.makeText(this, "Tap simulé à ($x, $y)", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        windowManager.removeView(floatingView)
    }
}
